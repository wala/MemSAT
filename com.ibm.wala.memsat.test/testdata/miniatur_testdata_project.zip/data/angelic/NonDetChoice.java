package data.angelic;

public class NonDetChoice {
    
    native public static Object chooseObject();
    
    native public static int chooseInt();
    
    native public static boolean chooseBoolean();
    
    public NonDetChoice() { super(); }
}
